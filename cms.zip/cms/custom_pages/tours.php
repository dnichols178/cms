<?php
declare(strict_types=1);

/**
 * Custom Page: Paducah Site Tour Reservations
 * Route: /tour-reservations
 */

// Override page metadata
$page_title = "Paducah Site Tour Reservations | Four Rivers Nuclear Partnership";
$node['title'] = "Paducah Deactivation Project Public Tour Reservations";

$db = get_db();

// 1. Ensure the reservation table exists
$db->exec("
    CREATE TABLE IF NOT EXISTS `tour_reservations` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `full_name` VARCHAR(120) NOT NULL,
        `email` VARCHAR(254) NOT NULL,
        `phone` VARCHAR(30) NOT NULL,
        `organization` VARCHAR(150) NULL,
        `attendees` TINYINT UNSIGNED NOT NULL DEFAULT 1,
        `tour_date` DATE NOT NULL,
        `us_citizen` TINYINT(1) NOT NULL DEFAULT 1,
        `special_accommodations` TEXT NULL,
        `ip_address` VARCHAR(45) NOT NULL,
        `status` ENUM('pending', 'confirmed', 'cancelled') NOT NULL DEFAULT 'pending',
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;
");

$success_msg = '';
$error_msg = '';

// 2. Process Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validate_csrf();

    $name            = trim($_POST['full_name'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $phone           = trim($_POST['phone'] ?? '');
    $organization    = trim($_POST['organization'] ?? '');
    $attendees       = max(1, min(10, (int)($_POST['attendees'] ?? 1)));
    $tour_date       = trim($_POST['tour_date'] ?? '');
    $us_citizen      = isset($_POST['us_citizen']) ? 1 : 0;
    $accommodations  = trim($_POST['accommodations'] ?? '');
    $ip              = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    if ($name === '' || $email === '' || $phone === '' || $tour_date === '') {
        $error_msg = 'Please complete all required fields (*).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_msg = 'Please provide a valid email address.';
    } elseif (!$us_citizen) {
        $error_msg = 'Due to DOE site security compliance, all tour participants must verify U.S. citizenship.';
    } else {
        // Save to Database
        $stmt = $db->prepare("
            INSERT INTO tour_reservations 
                (full_name, email, phone, organization, attendees, tour_date, us_citizen, special_accommodations, ip_address)
            VALUES 
                (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$name, $email, $phone, $organization, $attendees, $tour_date, $us_citizen, $accommodations, $ip]);
        $reservation_id = $db->lastInsertId();

        // Queue Staff Notification Email
        require_once __DIR__ . '/../includes/mailer.php';
        $notify_email = get_site_setting('notify_contact_email', 'communications@fourriversnuclearpartnership.com');
        $email_html = build_frnp_email_html(
            "New Tour Reservation (#{$reservation_id})",
            "<p>A new public tour reservation has been submitted:</p>
             <table style='width:100%; border-collapse:collapse; margin:15px 0;'>
                <tr><td style='padding:6px; font-weight:bold;'>Guest:</td><td>" . htmlspecialchars($name) . " (" . htmlspecialchars($organization) . ")</td></tr>
                <tr><td style='padding:6px; font-weight:bold;'>Email:</td><td>" . htmlspecialchars($email) . "</td></tr>
                <tr><td style='padding:6px; font-weight:bold;'>Phone:</td><td>" . htmlspecialchars($phone) . "</td></tr>
                <tr><td style='padding:6px; font-weight:bold;'>Date:</td><td>" . htmlspecialchars($tour_date) . "</td></tr>
                <tr><td style='padding:6px; font-weight:bold;'>Party Size:</td><td>{$attendees} guest(s)</td></tr>
             </table>",
            "http://" . ($_SERVER['HTTP_HOST'] ?? 'localhost') . base_path('admin/custom_pages.php'),
            "View Reservations"
        );
        queue_email($notify_email, "Tour Reservation Request: {$name}", $email_html, '', 'FRNP Communications', 1);

        $success_msg = "Your tour reservation request (#{$reservation_id}) has been submitted. Our security and communications staff will review your request and transmit visitor badge instructions to your email.";
    }
}
?>

<div class="custom-tour-page">
    <p style="margin-bottom: 24px; font-size: 1.05rem; color: #475569; line-height: 1.6;">
        Four Rivers Nuclear Partnership hosts periodic guided educational and community tours of the Paducah Gaseous Diffusion Plant deactivation site. All guests must register in advance for security badging and site clearance.
    </p>

    <?php if ($success_msg): ?>
        <div class="notice" style="background:#e8f5e9; border-left:4px solid #2e7d32; padding:18px; margin-bottom:25px; color:#1b5e20;">
            <h4 style="margin:0 0 6px 0; color:#1b5e20;">✓ Reservation Request Received</h4>
            <p style="margin:0;"><?= htmlspecialchars($success_msg) ?></p>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="notice" style="background:#fef2f2; border-left:4px solid #b91c1c; padding:16px; margin-bottom:25px; color:#991b1b;">
            <?= htmlspecialchars($error_msg) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?= base_path('tours') ?>" style="background:#ffffff; border:1px solid var(--frnp-border); padding:30px; border-radius:6px; box-shadow:var(--box-shadow);">
        <input type="hidden" name="csrf_token" value="<?= get_csrf_token() ?>">

        <h3 style="color:var(--frnp-navy); margin-bottom:20px; padding-bottom:8px; border-bottom:2px solid #f1f5f9;">Guest Information</h3>

        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:15px;">
            <div class="form-row">
                <label style="display:block; font-weight:600; margin-bottom:6px;">Full Legal Name *</label>
                <input type="text" name="full_name" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" 
                       style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:4px;">
            </div>
            <div class="form-row">
                <label style="display:block; font-weight:600; margin-bottom:6px;">Organization / Affiliation</label>
                <input type="text" name="organization" value="<?= htmlspecialchars($_POST['organization'] ?? '') ?>" 
                       placeholder="e.g. West Kentucky Community College, Civic Group"
                       style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:4px;">
            </div>
        </div>

        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:15px;">
            <div class="form-row">
                <label style="display:block; font-weight:600; margin-bottom:6px;">Email Address *</label>
                <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                       style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:4px;">
            </div>
            <div class="form-row">
                <label style="display:block; font-weight:600; margin-bottom:6px;">Phone Number *</label>
                <input type="tel" name="phone" required value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" 
                       placeholder="(270) 555-0100"
                       style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:4px;">
            </div>
        </div>

        <h3 style="color:var(--frnp-navy); margin:25px 0 20px; padding-bottom:8px; border-bottom:2px solid #f1f5f9;">Tour Details</h3>

        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:15px;">
            <div class="form-row">
                <label style="display:block; font-weight:600; margin-bottom:6px;">Preferred Tour Date *</label>
                <input type="date" name="tour_date" required min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($_POST['tour_date'] ?? '') ?>" 
                       style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:4px;">
            </div>
            <div class="form-row">
                <label style="display:block; font-weight:600; margin-bottom:6px;">Party Size *</label>
                <select name="attendees" style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:4px;">
                    <?php for ($i = 1; $i <= 6; $i++): ?>
                        <option value="<?= $i ?>" <?= ((int)($_POST['attendees'] ?? 1) === $i) ? 'selected' : '' ?>><?= $i ?> Guest<?= $i > 1 ? 's' : '' ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>

        <div class="form-row" style="margin-bottom:20px;">
            <label style="display:block; font-weight:600; margin-bottom:6px;">Special Access / Accommodations</label>
            <textarea name="accommodations" rows="3" placeholder="Mobility assistance, dietary restrictions for full-day briefings, etc." 
                      style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:4px;"><?= htmlspecialchars($_POST['accommodations'] ?? '') ?></textarea>
        </div>

        <div style="background:#f8fafc; border:1px solid #e2e8f0; padding:15px; border-radius:4px; margin-bottom:25px;">
            <label style="display:flex; align-items:flex-start; gap:10px; cursor:pointer; font-size:0.92rem; color:#334155;">
                <input type="checkbox" name="us_citizen" value="1" required style="margin-top:3px;">
                <span>I confirm that all members of my party are <strong>United States citizens</strong> and agree to present government-issued photo identification (REAL ID or Passport) upon arrival at the Paducah Site security gate.</span>
            </label>
        </div>

        <button type="submit" class="btn-primary" style="padding:12px 28px; font-size:1rem;">Submit Tour Reservation Request</button>
    </form>
</div>